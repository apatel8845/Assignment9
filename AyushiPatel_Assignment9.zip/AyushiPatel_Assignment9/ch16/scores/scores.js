"use strict";
var $ = function (id) { 
    return document.getElementById(id); 
};

var scores = [];
var namenumbers= [];
var i = 0;
var sum = 0;

var displayscores = function () {   
    
    while (i < namenumbers.length) {
        $("scores").value += namenumbers[i] + "\n";
        sum += parseFloat(scores[i]);
        i++;
    }
    
    var average = sum / namenumbers.length;
    $("average_score").value = average;
};


var addnumbers = function () {
    
    if (isNaN($("score").value) || $("score").value < 0) {
        alert("Please enter a valid number");
    }
    
    
    if ($("first_name").value == "" || $("last_name").value == "") {
        alert("Please enter a valid name ");
    }
    
    if (!isNaN($("score").value) && $("score").value >= 0 && $("first_name").value != "" && $("last_name").value != "") {
        parseFloat(scores.push($("score").value));
        namenumbers.push(($("last_name").value) + ", " + ($("first_name").value) + " : " + ($("score").value));
        displayscores();
    } 
    
    $("first_name").value = "";
    $("last_name").value = "";
    $("score").value = "";
    $("first_name").focus();
    
};

var clearnumbers = function () {   
    
   
    scores = [];
    namenumbers = [];
    
  
    $("average_score").value = "";
    $("first_name").value = "";
    $("last_name").value = "";
    $("scores").value = "";
    $("score").value = "";
    
  
    $("first_name").focus();
};

var sortnumbers = function () { 
    
  
    $("scores").value = "";
   
    var sort = namenumbers.sort();
    
  
    for (i = 0; i < namenumbers.length; i++) {
        $("scores").value += sort[i] + "\n";
    }
    
};

window.onload = function () {
    $("add_button").onclick = addnumbers;
    $("clear_button").onclick = clearnumbers;    
    $("sort_button").onclick = sortnumbers;    
    $("first_name").focus();
};