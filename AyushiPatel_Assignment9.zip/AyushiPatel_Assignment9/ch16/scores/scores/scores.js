"use strict";
var $ = function (id) { 
    return document.getElementById(id); 
};

var scores = [];
var namenums= [];
var i = 0;
var sum = 0;

var displayscores = function () {   
    
    while (i < namenums.length) {
        $("scores").value += namenums[i] + "\n";
        sum += parseFloat(scores[i]);
        i++;
    }
    
    var avg = sum / namenums.length;
    $("avgscore").value = avg;
};


var addnum = function () {
    
    if (isNaN($("score").value) || $("score").value < 0) {
        alert("Please enter a valid number");
    }
    
    
    if ($("fname").value == "" || $("lname").value == "") {
        alert("Please enter a valid name ");
    }
    
    if (!isNaN($("score").value) && $("score").value >= 0 && $("fname").value != "" && $("lname").value != "") {
        parseFloat(scores.push($("score").value));
        namenums.push(($("lname").value) + ", " + ($("fname").value) + " : " + ($("score").value));
        displayscores();
    } 
    
    $("fname").value = "";
    $("lname").value = "";
    $("score").value = "";
    $("fname").focus();
    
};

var clrnum = function () {   
    
   
    scores = [];
    namenums = [];
    
  
    $("avgscore").value = "";
    $("fname").value = "";
    $("lname").value = "";
    $("scores").value = "";
    $("score").value = "";
    
  
    $("fname").focus();
};

var sortnum = function () { 
    
  
    $("scores").value = "";
   
    var sort = namenums.sort();
    
  
    for (i = 0; i < namenums.length; i++) {
        $("scores").value += sort[i] + "\n";
    }
    
};

window.onload = function () {
    $("addbtn").onclick = addnum;
    $("clearbtn").onclick = clrnum;    
    $("sortbtn").onclick = sortnum;    
    $("fname").focus();
};