"use strict";
$(document).ready(function(){
    var isDate = function(text) {
        if( ! /^[01]?\d\/[0-3]\d\/\d{4}$/.test(text) ) return false;
        
        var i1 = text.indexOf( "/" );
        var i2 = text.indexOf( "/", i1 + 1 );
        var mon = parseInt( text.substring( 0, i1 ) );
        var day = parseInt( text.substring( i1 + 1, i2 ) );
        
        if( mon < 1 || mon > 12 ) { return false; }
        //if( day > 31 ) { return false; }
        else {
            switch( mon ) {
                case 2:
                    if ( day > 28 ) { return false; } 
                    break;
                case 4:
                case 6:
                case 9:
                case 11:
                    if ( day > 30 ) { return false; }
                    break;
                default:
                    if ( day > 31 ) { return false; }
                    break;
            }
        }
        return true; 
    };
    
    $( "#save" ).click(function() {
        $("span").text("");  
        var isValid = true;  
       
        var userInfo= new Object();
        var email = $("#email").val();
        var phone = $("#phone").val();
        var zip = $("#zip").val();
        var dob = $("#dob").val();
        
        userInfo["email"]=email;
        userInfo["phone"]=phone;
        userInfo["zip"]=zip;
        userInfo["dob"]=dob;
        if ( email === "" || 
                !email.match(/^[\w\.\-]+@[\w\.\-]+\.[a-zA-Z]+$/) ) 
        {
            isValid = false;
            $( "#email" ).next().text("Enter a valid email.");
        }
        if ( phone === "" || !phone.match(/^\d{3}-\d{3}-\d{4}$/) ) {
            isValid = false;
            $( "#phone" ).next().text(
                "Enter a phone number in NNN-NNN-NNNN format.");
        }
        if ( zip === "" || !zip.match(/^\d{5}(-\d{4})?$/) ) {
            isValid = false;
            $( "#zip" ).next().text("Enter a valid zip code.");
        }
        if ( dob === "" || !isDate(dob) ) {
            isValid = false;
            $( "#dob" ).next().text(
                "Enter a valid date in MM/DD/YYYY format.");
        }
        
        if ( isValid ) {  
           
            sessionStorage.email = email;
            sessionStorage.phone = phone;
            sessionStorage.zip = zip;
            sessionStorage.dob = dob;
            sessionStorage.profile="";
            
            for(var key in userInfo){
                sessionStorage.profile=sessionStorage.profile+key+"="+userInfo[key]+"|";
                
                }
            sessionStorage.profile=sessionStorage.profile.substr(0,sessionStorage.profile.length - 2);
          
            location.href = "profile.html";
        }
        
        $("#email").focus(); 
    });
    
   
    $("#email").focus();
});